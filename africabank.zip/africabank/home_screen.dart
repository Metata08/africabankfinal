import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  // static const IconData account_balance = IconData(0xe040, fontFamily: 'MaterialIcons');

  @override
  Widget build(BuildContext context) {
    // Scaffold est l'échafaudage de base de tout écran Material Design.
    return Scaffold(
      // 1. La barre de titre (la "porte d'entrée").
      appBar: AppBar(
        toolbarHeight: 0,
        backgroundColor: Colors.white,
        // Ajoutons un peu de couleur
      ),

      // 2. Le corps de la page.
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
              color: Color(0xFF154478),
              // height: 30,
              padding: EdgeInsets.all(10),
              child: Center(
                  child: Text(
                'WELCOME !',
                style: TextStyle(
                    fontSize: 30, color: Color(0xFFFCFDFD), letterSpacing: 4.1),
              ))),
          Container(
            color: Color(0xFF154478),
            width: double.infinity,
            padding: EdgeInsets.only(top: 10, bottom: 10),
            child: Icon(Icons.account_balance_sharp,
                size: 200, color: Color(0xFFFCFDFD)),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(top: 50, right: 100, left: 100),
              child: Column(
                spacing: 10,
                children: [
                  TextField(
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.person),
                      hintText: 'UserName or Email',
                      hintStyle: TextStyle(color: Color(0xFF8F9EAB)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  TextField(
                    obscureText: true,
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.lock),
                      hintText: 'Password',
                      hintStyle: TextStyle(color: Color(0xFF8F9EAB)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(left: 120, right: 120),
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF154478),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                      child: Text(
                        "LOG IN",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  Column(spacing: 0, children: [
                    TextButton(
                      onPressed: () {},
                      child: Text(
                        "Forgot Password?",
                        style: TextStyle(
                            color: Color(0xFF2EC3EF),
                            decoration: TextDecoration.underline,
                            decorationColor: Color(0xFF2EC3EF),
                            decorationThickness: 1.5),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("New to AfricaBank? "),
                        TextButton(
                          onPressed: () {},
                          child: Text(
                            "Sign UP",
                            style: TextStyle(
                                color: Color(0xFF2EC3EF),
                                decoration: TextDecoration.underline,
                                decorationColor: Color(0xFF2EC3EF),
                                decorationThickness: 1.5),
                          ),
                        ),
                      ],
                    ),
                  ]),
                ],
              ),
            ),
          )
        ]),
      ),
    );
  }
}
