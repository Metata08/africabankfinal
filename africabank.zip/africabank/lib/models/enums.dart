enum StatutCompte {
  ACTIF,
  SUSPENDU,
  FERME,
}

enum StatutTransaction {
  EN_ATTENTE,
  TERMINEE,
  ECHOUEE,
}

enum StatutPaiement {
  EN_ATTENTE,
  PAYE,
  ECHOUE,
}

enum TypeFacture {
  EAU,
  ELECTRICITE,
  GAZ,
  INTERNET,
  TELEPHONE,
  ASSURANCE,
  AUTRE,
}

enum TypeTransaction {
  DEBIT,
  CREDIT,
  TRANSFERT,
}
