import 'package:cloud_firestore/cloud_firestore.dart';
import 'enums.dart';

class Compte {
  final String id;
  final String numeroCompte; // 🔒 garanti = numéro téléphone
  double solde;
  final String devise;
  StatutCompte statut;
  final DateTime dateCreation;

  // 🔐 Constructeur PRIVÉ
  Compte._({
    required this.id,
    required this.numeroCompte,
    required this.solde,
    required this.devise,
    required this.statut,
    required this.dateCreation,
  });

  /// ✅ Factory : création contrôlée du compte
  factory Compte.fromUtilisateur({
    required String id,
    required String numeroTelephone,
    String devise = "XOF",
  }) {
    return Compte._(
      id: id,
      numeroCompte: numeroTelephone, // 🔥 règle imposée ici
      solde: 0,
      devise: devise,
      statut: StatutCompte.ACTIF,
      dateCreation: DateTime.now(),
    );
  }

  factory Compte.fromMap(Map<String, dynamic> data, String id) {
    return Compte._(
      id: id,
      numeroCompte: data['numeroCompte'] ?? '',
      solde: (data['solde'] ?? 0.0).toDouble(),
      devise: data['devise'] ?? 'XOF',
      statut: StatutCompte.values.firstWhere(
          (e) => e.name == data['statut'],
          orElse: () => StatutCompte.ACTIF),
      dateCreation: DateTime.tryParse(data['dateCreation'] ?? '') ?? DateTime.now(),
    );
  }

  // =====================
  // MÉTHODES UML
  // =====================

  Future<void> crediter(double montant) async {
    solde += montant;
    await save();
  }

  Future<void> debiter(double montant) async {
    if (solde < montant) {
      throw Exception("Solde insuffisant");
    }
    solde -= montant;
    await save();
  }

  double consulterSolde() => solde;

  // =====================
  // SAUVEGARDE FIREBASE
  // =====================

  Future<void> save() async {
    await FirebaseFirestore.instance
        .collection('comptes')
        .doc(id)
        .set(toMap());
  }

  Map<String, dynamic> toMap() {
    return {
      'numeroCompte': numeroCompte,
      'solde': solde,
      'devise': devise,
      'statut': statut.name,
      'dateCreation': dateCreation.toIso8601String(),
    };
  }
}
