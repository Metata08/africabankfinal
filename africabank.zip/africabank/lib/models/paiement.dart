import 'package:cloud_firestore/cloud_firestore.dart';
import 'enums.dart';

class Paiement {
  final String id;
  final TypeFacture typeFacture;
  final String fournisseur;
  final double montant;
  StatutPaiement statut;
  final DateTime dateCreation;

  Paiement({
    required this.id,
    required this.typeFacture,
    required this.fournisseur,
    required this.montant,
    required this.statut,
    required this.dateCreation,
  });

  factory Paiement.fromMap(Map<String, dynamic> data, String id) {
    return Paiement(
      id: id,
      typeFacture: TypeFacture.values.firstWhere(
          (e) => e.name == data['typeFacture'], orElse: () => TypeFacture.AUTRE),
      fournisseur: data['fournisseur'] ?? '',
      montant: (data['montant'] ?? 0.0).toDouble(),
      statut: StatutPaiement.values.firstWhere(
            (e) => e.name == data['statut'], orElse: () => StatutPaiement.EN_ATTENTE),
      dateCreation: DateTime.tryParse(data['dateCreation'] ?? '') ?? DateTime.now(),
    );
  }

  // =====================
  // MÉTHODES UML
  // =====================

  Future<void> payerFacture() async {
    statut = StatutPaiement.PAYE;
    await save();
  }

  Future<void> annulerPaiement() async {
    statut = StatutPaiement.ECHOUE;
    await save();
  }

  // =====================
  // SAUVEGARDE FIREBASE
  // =====================

  Future<void> save() async {
    await FirebaseFirestore.instance
        .collection('paiements')
        .doc(id)
        .set(toMap());
  }

  Map<String, dynamic> toMap() {
    return {
      'typeFacture': typeFacture.name,
      'fournisseur': fournisseur,
      'montant': montant,
      'statut': statut.name,
      'dateCreation': dateCreation.toIso8601String(),
    };
  }
}
