import 'package:cloud_firestore/cloud_firestore.dart';
import 'enums.dart';

class Transaction {
  final String id;
  final String reference;
  final String compteSource;
  final String compteDestination;
  final double montant;
  final TypeTransaction type;
  StatutTransaction statut;
  final String message;
  final DateTime dateCreation;

  Transaction({
    required this.id,
    required this.reference,
    required this.compteSource,
    required this.compteDestination,
    required this.montant,
    required this.type,
    required this.statut,
    required this.message,
    required this.dateCreation,
  });

  factory Transaction.fromMap(Map<String, dynamic> data, String id) {
    return Transaction(
      id: id,
      reference: data['reference'] ?? '',
      compteSource: data['compteSource'] ?? '',
      compteDestination: data['compteDestination'] ?? '',
      montant: (data['montant'] ?? 0.0).toDouble(),
      type: TypeTransaction.values.firstWhere(
          (e) => e.name == data['type'], orElse: () => TypeTransaction.TRANSFERT),
      statut: StatutTransaction.values.firstWhere(
          (e) => e.name == data['statut'], orElse: () => StatutTransaction.EN_ATTENTE),
      message: data['message'] ?? '',
      dateCreation: DateTime.tryParse(data['dateCreation'] ?? '') ?? DateTime.now(),
    );
  }

  // =====================
  // MÉTHODES UML
  // =====================

  Future<void> effectuer() async {
    statut = StatutTransaction.TERMINEE;
    await save();
  }

  Future<void> annuler() async {
    statut = StatutTransaction.ECHOUEE;
    await save();
  }

  // =====================
  // SAUVEGARDE FIREBASE
  // =====================

  Future<void> save() async {
    await FirebaseFirestore.instance
        .collection('transactions')
        .doc(id)
        .set(toMap());
  }

  Map<String, dynamic> toMap() {
    return {
      'reference': reference,
      'compteSource': compteSource,
      'compteDestination': compteDestination,
      'montant': montant,
      'type': type.name,
      'statut': statut.name,
      'message': message,
      'dateCreation': dateCreation.toIso8601String(),
    };
  }
}
