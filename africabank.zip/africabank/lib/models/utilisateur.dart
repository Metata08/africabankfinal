import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Utilisateur {
  final String id;
  String prenom;
  String nom;
  String numeroTelephone; // = numéro de compte
  String adresse;
  String email;
  String motDePasse;

  Utilisateur({
    required this.id,
    required this.prenom,
    required this.nom,
    required this.numeroTelephone,
    required this.adresse,
    required this.email,
    required this.motDePasse,
  });

  factory Utilisateur.fromMap(Map<String, dynamic> data, String id) {
    return Utilisateur(
      id: id,
      prenom: data['prenom'] ?? '',
      nom: data['nom'] ?? '',
      numeroTelephone: data['numeroTelephone'] ?? '',
      adresse: data['adresse'] ?? '',
      email: data['email'] ?? '',
      motDePasse: '', // Sécurité : ne pas stocker/récupérer le mot de passe
    );
  }

  // =====================
  // MÉTHODES UML
  // =====================

  /// Connexion utilisateur
  Future<User?> seConnecter() async {
    final cred = await FirebaseAuth.instance
        .signInWithEmailAndPassword(
      email: email,
      password: motDePasse,
    );
    return cred.user;
  }

  /// Déconnexion
  Future<void> seDeconnecter() async {
    await FirebaseAuth.instance.signOut();
  }

  /// Mise à jour du profil
  Future<void> mettreAJourProfil() async {
    await FirebaseFirestore.instance
        .collection('utilisateurs')
        .doc(id)
        .update(toMap());
  }

  // =====================
  // SAUVEGARDE FIREBASE
  // =====================

  Future<void> save() async {
    await FirebaseFirestore.instance
        .collection('utilisateurs')
        .doc(id)
        .set(toMap());
  }

  Map<String, dynamic> toMap() {
    return {
      'prenom': prenom,
      'nom': nom,
      'numeroTelephone': numeroTelephone,
      'adresse': adresse,
      'email': email,
    };
  }
}
