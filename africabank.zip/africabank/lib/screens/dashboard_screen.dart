import 'package:africabank/models/compte.dart';
import 'package:africabank/models/utilisateur.dart';
import 'package:africabank/widgets/balance_card.dart';
import 'package:africabank/widgets/custom_app_bar.dart';
import 'package:africabank/widgets/transaction_item.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'package:africabank/widgets/skeleton.dart';


class TransactionPage extends StatefulWidget {
  const TransactionPage({super.key});

  @override
  State<TransactionPage> createState() => _TransactionPageState();
}

class _TransactionPageState extends State<TransactionPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  User? _currentUser;

  @override
  void initState() {
    super.initState();
    _currentUser = FirebaseAuth.instance.currentUser;
  }

  @override
  Widget build(BuildContext context) {
    if (_currentUser == null) {
      return const Scaffold(
        body: Center(child: Text("No user logged in")),
      );
    }

    return Scaffold(
      key: _scaffoldKey,
      appBar: CustomAppBar(
        title: "",
        showMenu: true,
        showBack: false,
        onMenu: () {
          _scaffoldKey.currentState?.openDrawer();
        },
      ),
      drawer: buildAppDrawer(context),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('utilisateurs')
            .doc(_currentUser!.uid)
            .snapshots(),
        builder: (context, userSnapshot) {
          if (!userSnapshot.hasData) {
             // Skeleton for Header
             return Column(
               children: [
                 Container(
                    width: double.infinity,
                    color: const Color(0xFF154478),
                    padding: const EdgeInsets.only(top: 20, bottom: 30),
                    child: Column(
                      children: const [
                        Skeleton(height: 100, width: 100, borderRadius: 50),
                        SizedBox(height: 10),
                        Skeleton(height: 20, width: 150),
                        SizedBox(height: 5),
                        Skeleton(height: 14, width: 200),
                      ]
                    )
                 )
               ]
             );
          }

          final userData = userSnapshot.data!.data() as Map<String, dynamic>?;
          if (userData == null) return const Center(child: Text("User data not found"));

          final utilisateur = Utilisateur.fromMap(userData, _currentUser!.uid);

          return StreamBuilder<DocumentSnapshot>(
            stream: FirebaseFirestore.instance
                .collection('comptes')
                .doc(_currentUser!.uid)
                .snapshots(),
            builder: (context, accountSnapshot) {
              final accountData = accountSnapshot.data?.data() as Map<String, dynamic>?;
              final compte = accountData != null
                  ? Compte.fromMap(accountData, _currentUser!.uid)
                  : null;

              return Column(
                children: [
                  // ------------------- PARTIE BLEUE FIXE -------------------
                  Container(
                    width: double.infinity,
                    color: const Color(0xFF154478),
                    padding: const EdgeInsets.only(top: 20, bottom: 30),
                    child: Column(
                      children: [
                        const CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.white,
                          child: Icon(
                            Icons.person,
                            size: 55,
                            color: Color(0xFF154478),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          "${utilisateur.prenom} ${utilisateur.nom}",
                          style: const TextStyle(
                            fontSize: 22,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          utilisateur.email,
                          style: const TextStyle(fontSize: 16, color: Colors.white70),
                        ),
                        const SizedBox(height: 15),
                        // ---------- Balance Card ----------
                        BalanceCard(
                          balance: compte?.solde ?? 0.0,
                          currency: compte?.devise ?? 'XOF',
                        ),
                      ],
                    ),
                  ),

                  // ------------------- PARTIE BLANCHE SCROLL -------------------
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 20,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "LATEST TRANSACTIONS",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 20),
                          
                          // Transactions List
                          StreamBuilder<QuerySnapshot>(
                            stream: FirebaseFirestore.instance
                                .collection('transactions')
                                .where('compteSource', isEqualTo: utilisateur.numeroTelephone) // Simplified query
                                .limit(5)
                                .snapshots(),
                            builder: (context, txSnapshot) {
                              if (txSnapshot.hasError) {
                                return const Text("Error loading transactions");
                              }
                              if (!txSnapshot.hasData || txSnapshot.data!.docs.isEmpty) {
                                return const Text("No transactions yet.");
                              }

                              final validDocs = txSnapshot.data!.docs.where((doc) {
                                  // Filtrage manuel si nécessaire
                                  return true; 
                                }).toList();

                              return Column(
                                children: validDocs.map((doc) {
                                  final data = doc.data() as Map<String, dynamic>;
                                  final isNegative = data['compteSource'] == utilisateur.numeroTelephone; // Logique simple
                                  
                                  return TransactionItem(
                                    title: isNegative ? "Debit" : "Credit",
                                    subtitle: data['type'] ?? 'Transfer',
                                    amount: "${isNegative ? '-' : '+'}${data['montant']}", // Todo format currency
                                    positive: !isNegative,
                                  );
                                }).toList(),
                              );
                            },
                          ),
                          
                          const SizedBox(height: 10),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () {
                                context.go('/transaction_suivant');
                              },
                              child: const Text(
                                "MORE >>",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF154478),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}