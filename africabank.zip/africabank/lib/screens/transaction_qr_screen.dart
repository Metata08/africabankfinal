import 'dart:convert';
import 'package:africabank/models/compte.dart';
import 'package:africabank/models/utilisateur.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:barcode_widget/barcode_widget.dart';

class QrScreen extends StatefulWidget {
  const QrScreen({Key? key}) : super(key: key);

  @override
  State<QrScreen> createState() => _QrScreenState();
}

class _QrScreenState extends State<QrScreen> {
  final User? currentUser = FirebaseAuth.instance.currentUser;

  @override
  Widget build(BuildContext context) {
    const Color primaryBlue = Color(0xFF154478);
    const Color lightTextColor = Colors.white70;

    if (currentUser == null) {
      return const Scaffold(body: Center(child: Text("Please login")));
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF154478),
        elevation: 0,
        leading: IconButton(
          onPressed: () => context.go('/transaction'),
          icon: const Icon(Icons.chevron_left, color: Colors.white, size: 40),
        ),
        title: const Text(
          'TRANSACTION',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.normal,
            letterSpacing: 1.5,
          ),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('utilisateurs')
            .doc(currentUser!.uid)
            .snapshots(),
        builder: (context, userSnapshot) {
          if (!userSnapshot.hasData) return const Center(child: CircularProgressIndicator());
          
          final userData = userSnapshot.data!.data() as Map<String, dynamic>?;
          if (userData == null) return const Center(child: Text("User not found"));
          final utilisateur = Utilisateur.fromMap(userData, currentUser!.uid);

          return StreamBuilder<DocumentSnapshot>(
            stream: FirebaseFirestore.instance
                .collection('comptes')
                .doc(currentUser!.uid)
                .snapshots(),
            builder: (context, accountSnapshot) {
              if (!accountSnapshot.hasData) return const Center(child: CircularProgressIndicator());

              final accountData = accountSnapshot.data!.data() as Map<String, dynamic>?;
              final compte = accountData != null
                  ? Compte.fromMap(accountData, currentUser!.uid)
                  : null;

              // Data to encode
              final qrData = jsonEncode({
                'account': utilisateur.numeroTelephone,
                'balance': compte?.solde ?? 0.0,
                'name': "${utilisateur.prenom} ${utilisateur.nom}",
              });

              return Column(
                children: [
                  Expanded(
                    flex: 2,
                    child: Container(
                      width: double.infinity,
                      color: primaryBlue,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          const Text(
                            'SCAN THIS QR CODE',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                          const SizedBox(height: 20),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: QrImageView(
                              data: qrData,
                              version: QrVersions.auto,
                              size: 150.0,
                            ),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            "${utilisateur.prenom} ${utilisateur.nom}".toUpperCase(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            utilisateur.numeroTelephone,
                            style: const TextStyle(
                              color: lightTextColor,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Container(
                      padding: const EdgeInsets.all(30.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          const Text(
                            'CODE BARRE (Compte)',
                            style: TextStyle(color: Colors.grey, fontSize: 16),
                          ),
                          const SizedBox(height: 15),
                          BarcodeWidget(
                            barcode: Barcode.code128(),
                            data: utilisateur.numeroTelephone,
                            width: 200,
                            height: 60,
                            drawText: true,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
