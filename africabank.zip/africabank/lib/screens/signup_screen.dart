import 'package:africabank/models/compte.dart';
import 'package:africabank/models/utilisateur.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _termsAccepted = false;

  Future<void> _signUp() async {
    if (!_termsAccepted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please accept the Terms of Use.')),
      );
      return;
    }

    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();
    final name = _nameController.text.trim();
    final phone = _phoneController.text.trim();

    if (name.isEmpty || phone.isEmpty || email.isEmpty || password.isEmpty) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields.')),
      );
      return;
    }

    // Email Validation
    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegex.hasMatch(email)) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid email address.')),
      );
      return;
    }

    // Password Validation
    if (password.length < 6) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password must be at least 6 characters.')),
      );
      return;
    }

    try {
      // 1. Create Auth User
      final userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final uid = userCredential.user!.uid;

      // 2. Parse Name
      final nameParts = _nameController.text.trim().split(' ');
      final prenom = nameParts.first;
      final nom = nameParts.length > 1 ? nameParts.sublist(1).join(' ') : '';

      // 3. Create Utilisateur
      final utilisateur = Utilisateur(
        id: uid,
        prenom: prenom,
        nom: nom,
        numeroTelephone: _phoneController.text.trim(),
        adresse: '', // Default or ask user?
        email: _emailController.text.trim(),
        motDePasse: '', // Don't store password
      );

      await utilisateur.save();

      // 4. Create Compte
      final compte = Compte.fromUtilisateur(
        id: uid,
        numeroTelephone: utilisateur.numeroTelephone,
      );
      await compte.save();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Votre compte a été bien créé'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 3),
          ),
        );
        context.go('/home');
      }

    } on FirebaseAuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.message}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Unknown Error: $e')),
        );
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth  = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[

            // ------------------ PARTIE HAUTE : 25% ------------------
            Container(
              height: screenHeight * 0.25,
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF154478), Color(0xFF154478)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  SizedBox(height: screenHeight * 0.02),

                  // --- Ligne des 3 icônes ---
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.account_balance, color: Colors.white, size: 55),
                      SizedBox(width: 20),
                      Icon(Icons.link, color: Colors.white, size: 35),
                      SizedBox(width: 20),
                      Icon(Icons.phone_android, color: Colors.white, size: 50),
                    ],
                  ),

                  SizedBox(height: screenHeight * 0.015),

                  const Text(
                    'Connect to your bank account',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ),

            // ------------------ PARTIE BASSE : 75% ------------------
            Padding(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.12),
              child: Column(
                children: [

                  SizedBox(height: screenHeight * 0.04),

                  // -------- Name --------
                  SizedBox(
                    height: screenHeight * 0.065,
                    child: TextFormField(
                      controller: _nameController,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        hintText: 'Your Name',
                        prefixIcon: const Icon(Icons.person_outline),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: screenHeight * 0.02),

                  // -------- Bank account (Phone) --------
                  SizedBox(
                    height: screenHeight * 0.065,
                    child: TextFormField(
                      controller: _phoneController,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        hintText: 'Phone Number',
                        prefixIcon: const Icon(Icons.account_balance_wallet_outlined),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: screenHeight * 0.02),

                  // -------- Email --------
                  SizedBox(
                    height: screenHeight * 0.065,
                    child: TextFormField(
                      controller: _emailController,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        hintText: 'Email',
                        prefixIcon: const Icon(Icons.email_outlined),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: screenHeight * 0.02),

                  // -------- Password --------
                  SizedBox(
                    height: screenHeight * 0.065,
                    child: TextFormField(
                      controller: _passwordController,
                      obscureText: true,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        hintText: 'Password',
                        prefixIcon: const Icon(Icons.lock_outline),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: screenHeight * 0.01),

                  // -------- Password guidance --------
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Use 6 characters with a mix of letters,\n numbers & symbols.',
                      style: TextStyle(
                        color: Color(0xFF2EC3EF),
                        fontSize: 13,
                      ),
                    ),
                  ),

                  SizedBox(height: screenHeight * 0.01),

                  // -------- Terms checkbox --------
                  Row(
                    children: [
                      Checkbox(
                        value: _termsAccepted,
                        onChanged: (val) => setState(() => _termsAccepted = val ?? false),
                      ),
                      const Expanded(
                        child: Text(
                          "By signing up, you agree to Bank's Term of Use & Privacy Policy.",
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: screenHeight * 0.03),

                  // -------- Buttons SIGNUP / CANCEL --------
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: screenWidth * 0.35,
                        height: screenHeight * 0.05,
                        child: ElevatedButton(
                          onPressed: _signUp,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF154478),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                          child: const Text('SIGN UP', style: TextStyle(color: Colors.white)),
                        ),
                      ),

                      SizedBox(width: screenWidth * 0.04),

                      SizedBox(
                        width: screenWidth * 0.35,
                        height: screenHeight * 0.05,
                        child: OutlinedButton(
                          onPressed: () => context.go('/'),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Color(0xFF154478)),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                          child: const Text('CANCEL', style: TextStyle(color: Color(0xFF154478))),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: screenHeight * 0.02),

                  // -------- Already signed up? --------
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Already signed up? "),
                      TextButton(
                        onPressed: () => context.go('/'),
                        child: Text(
                          "LOG IN",
                          style: TextStyle(
                            color: Color(0xFF2EC3EF),
                            decoration: TextDecoration.underline,
                            decorationColor: Color(0xFF2EC3EF),
                            decorationThickness: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: screenHeight * 0.04),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
