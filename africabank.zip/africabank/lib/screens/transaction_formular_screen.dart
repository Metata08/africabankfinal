import 'package:africabank/models/compte.dart';
import 'package:africabank/models/transaction.dart' as model; // Alias pour éviter conflit
import 'package:africabank/models/utilisateur.dart';
import 'package:africabank/models/enums.dart'; // Pour TypeTransaction
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class TransactionFormScreen extends StatefulWidget {
  const TransactionFormScreen({Key? key}) : super(key: key);

  @override
  _TransactionFormScreenState createState() => _TransactionFormScreenState();
}

class _TransactionFormScreenState extends State<TransactionFormScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedAccount;
  String _selectedCurrency = 'XOF';
  
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();

  User? _currentUser;
  Utilisateur? _utilisateur;
  Compte? _compte;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _currentUser = FirebaseAuth.instance.currentUser;
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    if (_currentUser == null) return;
    
    final userDoc = await FirebaseFirestore.instance.collection('utilisateurs').doc(_currentUser!.uid).get();
    final accountDoc = await FirebaseFirestore.instance.collection('comptes').doc(_currentUser!.uid).get();

    if (userDoc.exists && accountDoc.exists) {
      if (mounted) {
        setState(() {
          _utilisateur = Utilisateur.fromMap(userDoc.data()!, _currentUser!.uid);
          _compte = Compte.fromMap(accountDoc.data()!, _currentUser!.uid);
        });
      }
    }
  }

  Future<void> _sendTransfer() async {
    if (!_formKey.currentState!.validate()) return;
    
    final amount = double.tryParse(_amountController.text.replaceAll(',', '')) ?? 0.0;
    final destination = _destinationController.text.trim();

    if (_compte == null || amount <= 0) {
       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid amount or account error')));
       return;
    }

    if (_compte!.solde < amount) {
       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Insufficient balance')));
       return;
    }

    setState(() => _isLoading = true);

    try {
      // 1. Débiter le compte source
      final newBalance = _compte!.solde - amount;
      await FirebaseFirestore.instance
          .collection('comptes')
          .doc(_currentUser!.uid)
          .update({'solde': newBalance});

      // 2. Créer la transaction
      final transaction = model.Transaction(
        id: '', // Auto-gen
        reference: "REF-${DateTime.now().millisecondsSinceEpoch}",
        compteSource: _utilisateur!.numeroTelephone, // On utilise le tél comme identifiant bancaire
        compteDestination: destination,
        montant: amount,
        type: TypeTransaction.TRANSFERT,
        statut: StatutTransaction.TERMINEE,
        message: _messageController.text,
        dateCreation: DateTime.now(),
      );

      await transaction.save();

      // Note: On ne gère pas le crédit du destinataire ici pour simplifier (requiert de trouver son UID via son tel)
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Transfer Successful!')));
        context.go('/home');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryBlue = Color(0xFF154478);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF154478),
        elevation: 0,
        leading: IconButton(
            onPressed: () => context.go('/transaction'),
            icon: const Icon(Icons.chevron_left, color: Colors.white, size: 40)),
        title: const Text(
          'TRANSACTION',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.normal,
            letterSpacing: 1.5,
          ),
        ),
        centerTitle: true,
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // Icons
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.payments, size: 100, color: primaryBlue),
                  Icon(Icons.swap_horiz_rounded, size: 100, color: primaryBlue)
                ],
              ),

              // From Bank Account
              const Text('From Bank Account',
                  style: TextStyle(color: primaryBlue, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextFormField(
                textAlign: TextAlign.left,
                readOnly: true,
                initialValue: _utilisateur?.numeroTelephone ?? 'Loading...',
                decoration: InputDecoration(
                  hintText: '0D 123 456',
                  filled: true,
                  fillColor: Colors.grey[200],
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: primaryBlue, width: 2.0),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
              const SizedBox(height: 20),

              // To Bank Account (Manual Entry for now)
              const Text('To Bank Account (Phone/ID)',
                  style: TextStyle(color: primaryBlue, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _destinationController,
                validator: (val) => val!.isEmpty ? 'Required' : null,
                decoration: InputDecoration(
                  hintText: 'Recipient ID',
                  enabledBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    borderSide: const BorderSide(color: primaryBlue, width: 2.0),
                  ),
                  border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                ),
              ),
              
              const SizedBox(height: 20),

              // Amount
              const Text('Amount',
                  style: TextStyle(color: primaryBlue, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Row(
                children: [
                  SizedBox(
                    width: 90,
                    child: DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(8)),
                          borderSide: BorderSide(color: primaryBlue, width: 2.0),
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                        contentPadding: EdgeInsets.symmetric(horizontal: 10),
                      ),
                      value: _selectedCurrency,
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedCurrency = newValue!;
                        });
                      },
                      items: <String>['XOF', 'EUR', 'USD']
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value, style: const TextStyle(fontSize: 16)),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextFormField(
                      controller: _amountController,
                      validator: (val) {
                        if (val == null || val.isEmpty) return 'Required';
                        if (double.tryParse(val) == null) return 'Invalid number';
                        return null;
                      },
                      decoration: const InputDecoration(
                        hintText: '0.00',
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(8)),
                          borderSide: BorderSide(color: primaryBlue, width: 2.0),
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text("Available Balance: ${_compte?.solde ?? 0.0} XOF", style: const TextStyle(color: Colors.grey)),

              const SizedBox(height: 20),

              // Messages
              const Text('Messages',
                  style: TextStyle(color: primaryBlue, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _messageController,
                decoration: const InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8)),
                    borderSide: BorderSide(color: primaryBlue, width: 2.0),
                  ),
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                ),
              ),
              const SizedBox(height: 40),

              // Action Buttons
              Row(
                children: [
                   Expanded(
                    child: ElevatedButton(
                      onPressed: _sendTransfer, // Call logic
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        backgroundColor: primaryBlue,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: const Text('SEND', style: TextStyle(color: Colors.white, fontSize: 16)),
                    ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => context.go('/transaction'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        side: const BorderSide(color: Colors.red, width: 2),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: const Text('CANCEL', style: TextStyle(color: Colors.red, fontSize: 16)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
