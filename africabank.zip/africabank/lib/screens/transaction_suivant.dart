import 'package:africabank/models/utilisateur.dart';
import 'package:africabank/widgets/transaction_item.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../widgets/custom_app_bar.dart';

class TransactionSuivant extends StatefulWidget {
  const TransactionSuivant({super.key});

  @override
  State<TransactionSuivant> createState() => _TransactionSuivantState();
}

class _TransactionSuivantState extends State<TransactionSuivant> {
  String searchQuery = "";
  String selectedType = "Tous";
  final User? currentUser = FirebaseAuth.instance.currentUser;

  @override
  Widget build(BuildContext context) {
    if (currentUser == null) {
      return const Scaffold(body: Center(child: Text("Please login")));
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: CustomAppBar(
        title: "Transactions",
        showMenu: false,
        showBack: true,
        onBack: () => context.go('/home'),
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('utilisateurs')
            .doc(currentUser!.uid)
            .snapshots(),
        builder: (context, userSnapshot) {
          if (!userSnapshot.hasData) return const Center(child: CircularProgressIndicator());

          final userData = userSnapshot.data!.data() as Map<String, dynamic>?;
          if (userData == null) return const Center(child: Text("User not found"));
          final utilisateur = Utilisateur.fromMap(userData, currentUser!.uid);

          return Column(
            children: [
              // --------- Carte solde ---------
               StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('comptes')
                    .doc(currentUser!.uid)
                    .snapshots(),
                builder: (context, accountSnapshot) {
                  final accountData = accountSnapshot.data?.data() as Map<String, dynamic>?;
                  final solde = accountData?['solde'] ?? 0.0;
                  return _buildBalanceCard(solde);
                }
              ),

              // --------- Barre de recherche ---------
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: "Rechercher...",
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 0, horizontal: 15),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: const BorderSide(color: Colors.grey),
                    ),
                  ),
                  onChanged: (value) {
                    setState(() => searchQuery = value);
                  },
                ),
              ),

              const SizedBox(height: 10),

              // --------- Filtres par type ---------
              _buildTypeFilters(),

              const SizedBox(height: 10),

              // --------- Liste des transactions ---------
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('transactions')
                      // On récupère toutes les transactions où l'utilisateur est impliqué
                      // Note: Firestore ne permet pas facilement le "OR" sur deux champs différents sans index composite.
                      // Pour simplifier ici, on prend celles où il est source OU destination (nécessite 2 requêtes ou filtrage client)
                      // Pour l'instant on filtre client-side pour simplifier l'exemple.
                      .snapshots(), 
                  builder: (context, txSnapshot) {
                    if (!txSnapshot.hasData) return const Center(child: CircularProgressIndicator());

                    final allDocs = txSnapshot.data!.docs;
                    
                    // Filtrage et Mapping
                    final filtered = allDocs.map((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      final isSource = data['compteSource'] == utilisateur.numeroTelephone;
                      final isDest = data['compteDestination'] == utilisateur.numeroTelephone;
                      
                      if (!isSource && !isDest) return null; // Pas concerné

                      final isDebit = isSource; // Si source, c'est un débit
                      
                      return {
                        'title': isDebit ? (data['compteDestination'] ?? 'Débit') : (data['compteSource'] ?? 'Crédit'),
                        'subtitle': data['message'] ?? (isDebit ? 'Envoi' : 'Reçu'),
                        'amount': "${isDebit ? '-' : '+'}${data['montant']} ${data['devise'] ?? 'XOF'}",
                        'positive': !isDebit,
                        'type': data['type'] ?? 'Transfert',
                      };
                    }).whereType<Map<String, dynamic>>().where((tx) {
                      // Filtre Recherche
                      final query = searchQuery.toLowerCase();
                      final matchesSearch = query.isEmpty ||
                          tx['title'].toString().toLowerCase().contains(query) ||
                          tx['subtitle'].toString().toLowerCase().contains(query);

                      // Filtre Type
                      final matchesType = selectedType == "Tous" || tx['type'] == selectedType;

                      return matchesSearch && matchesType;
                    }).toList();

                    if (filtered.isEmpty) {
                      return const Center(child: Text("Aucune transaction trouvée"));
                    }

                    return ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final tx = filtered[index];
                        final type = tx['type'] as String;

                        return TransactionItem(
                          title: tx['title'],
                          subtitle: tx['subtitle'],
                          amount: tx['amount'],
                          positive: tx['positive'],
                          icon: _iconForType(type),
                          iconBackground: _colorForType(type),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // ------------------ WIDGETS UI ------------------

  Widget _buildBalanceCard(double solde) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.all(20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF154478),
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 8,
            offset: Offset(0, 4),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Solde total",
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          const SizedBox(height: 8),
          Text(
            "$solde XOF",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Historique de vos dernières opérations",
            style: TextStyle(color: Colors.white70, fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildTypeFilters() {
    final types = ["Tous", "Transfert", "Facture", "Retrait", "Achat", "Salaire"];

    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: types.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final type = types[index];
          final selected = (type == selectedType);

          return GestureDetector(
            onTap: () => setState(() => selectedType = type),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: selected ? const Color(0xFF154478) : Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFF154478)),
              ),
              child: Text(
                type,
                style: TextStyle(
                  color:
                  selected ? Colors.white : const Color(0xFF154478),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ------------------ LOGIQUE ICONES ------------------

  IconData _iconForType(String type) {
    switch (type) {
      case 'Transfert':
        return Icons.swap_horiz;
      case 'Facture':
        return Icons.receipt_long;
      case 'Retrait':
        return Icons.money_off;
      case 'Achat':
        return Icons.shopping_cart;
      case 'Salaire':
        return Icons.account_balance_wallet;
      default:
        return Icons.attach_money;
    }
  }

  Color _colorForType(String type) {
    switch (type) {
      case 'Transfert':
        return Colors.blueAccent;
      case 'Facture':
        return Colors.orange;
      case 'Retrait':
        return Colors.redAccent;
      case 'Achat':
        return Colors.purpleAccent;
      case 'Salaire':
        return Colors.green;
      default:
        return const Color(0xFF154478);
    }
  }
}
